(() => {
  'use strict';

  const MIN_SPEED = 0.25;
  const MAX_SPEED = 3;
  const STEP = 0.05;
  const STORAGE_KEY = 'yt-speed-hotkeys:last-speed';
  const CHIP_SPEEDS = [1, 1.25, 1.5, 1.75, 2, 3];

  const roundSpeed = (speed) => Math.round(Number(speed) * 100) / 100;
  const clampSpeed = (speed) => {
    const numeric = Number(speed);
    if (!Number.isFinite(numeric)) return 1;
    return Math.min(MAX_SPEED, Math.max(MIN_SPEED, roundSpeed(numeric)));
  };
  const formatSpeed = (speed) => `${Number(clampSpeed(speed).toFixed(2))}x`;
  const decreaseSpeed = (speed) => clampSpeed(Number(speed) - STEP);
  const increaseSpeed = (speed) => clampSpeed(Number(speed) + STEP);
  const speedFromDigit = (key) => (key === '1' ? 1 : key === '2' ? 2 : key === '3' ? 3 : null);
  const shouldIgnoreKeyEvent = (event) => {
    if (!event || event.defaultPrevented || event.ctrlKey || event.metaKey || event.altKey) return true;
    const target = event.target;
    if (!target) return false;
    const tagName = String(target.tagName || '').toUpperCase();
    return target.isContentEditable || tagName === 'INPUT' || tagName === 'TEXTAREA' || tagName === 'SELECT';
  };

  let overlay = null;
  let slider = null;
  let valueEl = null;
  let chips = [];
  let hideTimer = null;
  let currentVideo = null;
  let restoreFullscreenElement = null;
  let restoreFullscreenUntil = 0;

  function getVideo() {
    const videos = [...document.querySelectorAll('video')];
    return videos.find((video) => !video.disablePictureInPicture && video.readyState >= 1) || videos[0] || null;
  }

  function currentSpeed() {
    const video = getVideo();
    return clampSpeed(video?.playbackRate || readStoredSpeed() || 1);
  }

  function readStoredSpeed() {
    try {
      return clampSpeed(localStorage.getItem(STORAGE_KEY));
    } catch (_) {
      return 1;
    }
  }

  function storeSpeed(speed) {
    try {
      localStorage.setItem(STORAGE_KEY, String(clampSpeed(speed)));
    } catch (_) {
      // Ignore private-storage failures.
    }
  }

  function setVideoSpeed(speed) {
    const nextSpeed = clampSpeed(speed);
    const video = getVideo();
    if (video) {
      video.playbackRate = nextSpeed;
      currentVideo = video;
    }
    storeSpeed(nextSpeed);
    updateUi(nextSpeed);
    return nextSpeed;
  }

  function updateUi(speed = currentSpeed()) {
    const safeSpeed = clampSpeed(speed);
    if (valueEl) valueEl.textContent = formatSpeed(safeSpeed);
    if (slider) {
      slider.value = String(safeSpeed);
      slider.setAttribute('aria-valuenow', String(safeSpeed));
      slider.style.setProperty('--ytsh-progress', `${((safeSpeed - MIN_SPEED) / (MAX_SPEED - MIN_SPEED)) * 100}%`);
    }
    for (const chip of chips) {
      chip.classList.toggle('ytsh-active', Math.abs(Number(chip.dataset.speed) - safeSpeed) < 0.001);
    }
  }

  function ensureOverlay() {
    if (overlay) return overlay;

    const style = document.createElement('style');
    style.textContent = `
      .ytsh-overlay {
        position: fixed;
        inset: 0;
        z-index: 2147483647;
        display: none;
        align-items: center;
        justify-content: center;
        padding: 24px;
        font-family: Roboto, Arial, sans-serif;
        color: #fff;
        pointer-events: none;
      }
      .ytsh-overlay.ytsh-open { display: flex; }
      .ytsh-panel {
        pointer-events: auto;
        width: min(760px, calc(100vw - 48px));
        border-radius: 24px;
        background: rgba(13, 13, 13, 0.84);
        box-shadow: 0 18px 60px rgba(0, 0, 0, 0.45);
        overflow: hidden;
        backdrop-filter: blur(12px);
      }
      .ytsh-header {
        height: 76px;
        display: flex;
        align-items: center;
        gap: 20px;
        padding: 0 28px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.18);
        font-size: 24px;
        font-weight: 700;
      }
      .ytsh-back {
        border: 0;
        background: transparent;
        color: #fff;
        font: inherit;
        font-size: 44px;
        line-height: 1;
        cursor: pointer;
        padding: 0 4px 4px 0;
      }
      .ytsh-body { padding: 42px 30px 28px; }
      .ytsh-value {
        text-align: center;
        font-size: 38px;
        font-weight: 700;
        margin-bottom: 42px;
      }
      .ytsh-controls {
        display: grid;
        grid-template-columns: 64px 1fr 64px;
        gap: 26px;
        align-items: center;
      }
      .ytsh-round {
        width: 64px;
        height: 64px;
        border-radius: 50%;
        border: 0;
        background: rgba(255, 255, 255, 0.14);
        color: white;
        font-size: 42px;
        font-weight: 800;
        cursor: pointer;
      }
      .ytsh-round:focus-visible, .ytsh-back:focus-visible, .ytsh-chip:focus-visible {
        outline: 3px solid #3ea6ff;
        outline-offset: 3px;
      }
      .ytsh-round:hover { background: rgba(255, 255, 255, 0.22); }
      .ytsh-plus { box-shadow: 0 0 0 3px #3ea6ff inset; }
      .ytsh-slider {
        --ytsh-progress: 27%;
        width: 100%;
        accent-color: #fff;
        cursor: pointer;
      }
      .ytsh-slider::-moz-range-track { height: 8px; border-radius: 999px; background: rgba(255,255,255,.24); }
      .ytsh-slider::-moz-range-progress { height: 8px; border-radius: 999px; background: #fff; }
      .ytsh-slider::-moz-range-thumb { width: 32px; height: 32px; border: 0; border-radius: 50%; background: #fff; }
      .ytsh-chips {
        display: flex;
        flex-wrap: wrap;
        gap: 14px;
        margin-top: 38px;
      }
      .ytsh-chip {
        border: 0;
        border-radius: 24px;
        padding: 16px 28px;
        min-width: 104px;
        background: rgba(255, 255, 255, 0.13);
        color: white;
        font-size: 22px;
        font-weight: 700;
        cursor: pointer;
      }
      .ytsh-chip:hover, .ytsh-chip.ytsh-active { background: rgba(255, 255, 255, 0.26); }
      .ytsh-chip-note { display: block; margin-top: 8px; font-size: 14px; font-weight: 500; opacity: .75; }
      @media (max-width: 520px) {
        .ytsh-panel { border-radius: 18px; }
        .ytsh-header { height: 58px; padding: 0 18px; font-size: 18px; }
        .ytsh-back { font-size: 34px; }
        .ytsh-body { padding: 28px 20px 22px; }
        .ytsh-value { font-size: 32px; margin-bottom: 30px; }
        .ytsh-controls { grid-template-columns: 48px 1fr 48px; gap: 14px; }
        .ytsh-round { width: 48px; height: 48px; font-size: 32px; }
        .ytsh-chip { min-width: 80px; padding: 12px 18px; font-size: 18px; }
      }
    `;
    document.documentElement.append(style);

    overlay = document.createElement('div');
    overlay.className = 'ytsh-overlay';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-label', 'Playback speed');

    const panel = document.createElement('div');
    panel.className = 'ytsh-panel';

    const header = document.createElement('div');
    header.className = 'ytsh-header';

    const backButton = document.createElement('button');
    backButton.type = 'button';
    backButton.className = 'ytsh-back';
    backButton.setAttribute('aria-label', 'Close speed panel');
    backButton.textContent = '‹';

    const title = document.createElement('div');
    title.textContent = 'Playback speed';

    const body = document.createElement('div');
    body.className = 'ytsh-body';

    valueEl = document.createElement('div');
    valueEl.className = 'ytsh-value';
    valueEl.textContent = '1x';

    const controls = document.createElement('div');
    controls.className = 'ytsh-controls';

    const minusButton = document.createElement('button');
    minusButton.type = 'button';
    minusButton.className = 'ytsh-round ytsh-minus';
    minusButton.setAttribute('aria-label', 'Decrease playback speed');
    minusButton.textContent = '−';

    slider = document.createElement('input');
    slider.className = 'ytsh-slider';
    slider.type = 'range';
    slider.min = String(MIN_SPEED);
    slider.max = String(MAX_SPEED);
    slider.step = String(STEP);
    slider.setAttribute('aria-label', 'Playback speed slider');

    const plusButton = document.createElement('button');
    plusButton.type = 'button';
    plusButton.className = 'ytsh-round ytsh-plus';
    plusButton.setAttribute('aria-label', 'Increase playback speed');
    plusButton.textContent = '+';

    const chipWrap = document.createElement('div');
    chipWrap.className = 'ytsh-chips';
    chipWrap.setAttribute('aria-label', 'Preset playback speeds');

    header.append(backButton, title);
    controls.append(minusButton, slider, plusButton);
    body.append(valueEl, controls, chipWrap);
    panel.append(header, body);
    overlay.append(panel);
    document.documentElement.append(overlay);

    chips = CHIP_SPEEDS.map((speed) => {
      const chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'ytsh-chip';
      chip.dataset.speed = String(speed);
      chip.append(document.createTextNode(Number(speed.toFixed(2)).toString().replace('.', ',')));
      if (speed === 1) {
        const note = document.createElement('span');
        note.className = 'ytsh-chip-note';
        note.textContent = 'Normal';
        chip.append(note);
      }
      chip.addEventListener('click', () => setVideoSpeed(speed));
      chipWrap.append(chip);
      return chip;
    });

    backButton.addEventListener('click', hideOverlay);
    minusButton.addEventListener('click', () => setVideoSpeed(decreaseSpeed(currentSpeed())));
    plusButton.addEventListener('click', () => setVideoSpeed(increaseSpeed(currentSpeed())));
    slider.addEventListener('input', () => setVideoSpeed(slider.value));
    overlay.addEventListener('click', (event) => {
      if (event.target === overlay) hideOverlay();
    });

    updateUi();
    return overlay;
  }

  function showOverlay() {
    ensureOverlay();
    clearTimeout(hideTimer);
    updateUi();
    overlay.classList.add('ytsh-open');
    overlay.querySelector('.ytsh-plus')?.focus({ preventScroll: true });
  }

  function hideOverlay() {
    if (!overlay) return;
    overlay.classList.remove('ytsh-open');
  }

  function overlayIsOpen() {
    return Boolean(overlay?.classList.contains('ytsh-open'));
  }

  function fullscreenElement() {
    return document.fullscreenElement || document.webkitFullscreenElement || null;
  }

  function requestFullscreen(element) {
    if (!element) return;
    const request = element.requestFullscreen || element.webkitRequestFullscreen;
    if (!request) return;
    try {
      Promise.resolve(request.call(element)).catch(() => {});
    } catch (_) {
      // Browsers may reject if fullscreen restoration is not considered part of
      // the Escape key user activation. In that case the menu still closes.
    }
  }

  function shouldCloseOverlayAfterFullscreenChange() {
    return overlayIsOpen() && !fullscreenElement();
  }

  function handleFullscreenChange() {
    const now = Date.now();
    if (!fullscreenElement() && restoreFullscreenElement && now < restoreFullscreenUntil) {
      requestFullscreen(restoreFullscreenElement);
      restoreFullscreenElement = null;
      restoreFullscreenUntil = 0;
      return;
    }

    restoreFullscreenElement = null;
    restoreFullscreenUntil = 0;

    if (shouldCloseOverlayAfterFullscreenChange()) {
      hideOverlay();
    }
  }

  function toggleOverlay() {
    if (overlayIsOpen()) hideOverlay();
    else showOverlay();
  }

  function handleKeydown(event) {
    if (shouldIgnoreKeyEvent(event)) return;

    if (!overlayIsOpen() && event.key?.toLowerCase() === 's') {
      const video = getVideo();
      if (!video) return;
      event.preventDefault();
      event.stopPropagation();
      toggleOverlay();
      return;
    }

    if (!overlayIsOpen()) return;

    const digitSpeed = speedFromDigit(event.key);
    if (digitSpeed !== null) {
      event.preventDefault();
      event.stopPropagation();
      setVideoSpeed(digitSpeed);
      return;
    }

    if (event.key === 'ArrowLeft') {
      event.preventDefault();
      event.stopPropagation();
      setVideoSpeed(decreaseSpeed(currentSpeed()));
      return;
    }

    if (event.key === 'ArrowRight') {
      event.preventDefault();
      event.stopPropagation();
      setVideoSpeed(increaseSpeed(currentSpeed()));
      return;
    }

    if (event.key === 'Escape' || event.key === 'Esc') {
      const currentFullscreenElement = fullscreenElement();
      if (currentFullscreenElement) {
        restoreFullscreenElement = currentFullscreenElement;
        restoreFullscreenUntil = Date.now() + 1500;
      }
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      hideOverlay();
      return;
    }

    if (event.key?.toLowerCase() === 's') {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      hideOverlay();
    }
  }

  function attachVideoRateSync() {
    const video = getVideo();
    if (!video || video === currentVideo) return;
    currentVideo = video;
    const stored = readStoredSpeed();
    if (stored && Math.abs(video.playbackRate - stored) > 0.001) {
      video.playbackRate = stored;
    }
    video.addEventListener('ratechange', () => updateUi(video.playbackRate));
  }

  window.addEventListener('keydown', handleKeydown, true);
  document.addEventListener('fullscreenchange', handleFullscreenChange, true);
  document.addEventListener('webkitfullscreenchange', handleFullscreenChange, true);
  setInterval(attachVideoRateSync, 1000);
  attachVideoRateSync();
})();
