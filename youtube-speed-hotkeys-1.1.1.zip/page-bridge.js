(() => {
  'use strict';

  window.ytshPageBridgeInstalled = true;

  const SPEED_MENU_LABELS = [
    'Playback speed',
    'Speed',
    'Скорость воспроизведения',
    'Скорость',
    'Afspeelsnelheid',
    'Snelheid',
    'Wiedergabegeschwindigkeit',
    'Velocidad de reproducción',
    'Vitesse de lecture',
  ];

  function getPlayer() {
    return document.querySelector('.html5-video-player') || document.querySelector('#movie_player');
  }

  function settingsMenuVisible() {
    const menu = document.querySelector('.ytp-popup.ytp-settings-menu');
    return Boolean(menu && menu.style.display !== 'none' && menu.getClientRects().length > 0);
  }

  function speedSubmenuVisible() {
    const menu = document.querySelector('.ytp-popup.ytp-settings-menu');
    if (!menu) return false;
    return [...menu.querySelectorAll('.ytp-menuitem')].some((item) => /^(0\.25|0\.5|0\.75|Normal|1|1\.25|1\.5|1\.75|2)/.test(item.textContent.trim()));
  }

  function clickSettingsButton() {
    const button = document.querySelector('.ytp-settings-button');
    if (!button) return false;
    button.click();
    return true;
  }

  function findPlaybackSpeedMenuItem() {
    const menu = document.querySelector('.ytp-popup.ytp-settings-menu');
    if (!menu) return null;
    const items = [...menu.querySelectorAll('.ytp-menuitem')];
    return items.find((item) => {
      const text = item.textContent.replace(/\s+/g, ' ').trim();
      const aria = item.getAttribute('aria-label') || '';
      return SPEED_MENU_LABELS.some((label) => text.includes(label) || aria.includes(label));
    }) || null;
  }

  function openPlayerSettingsMenu() {
    const player = getPlayer();
    if (player?.openSettingsMenuItem) {
      try {
        player.openSettingsMenuItem('playbackRate');
        return true;
      } catch (_) {
        try {
          player.openSettingsMenuItem('speed');
          return true;
        } catch (_) {
          // Fall through.
        }
      }
    }
    return clickSettingsButton();
  }

  function enterPlaybackSpeedSubmenu() {
    if (speedSubmenuVisible()) return true;
    const playbackSpeedItem = findPlaybackSpeedMenuItem();
    if (!playbackSpeedItem) return false;
    playbackSpeedItem.click();
    return true;
  }

  function openYoutubeSpeedMenu() {
    if (!settingsMenuVisible() && !openPlayerSettingsMenu()) return;
    setTimeout(enterPlaybackSpeedSubmenu, 0);
    setTimeout(enterPlaybackSpeedSubmenu, 80);
    setTimeout(enterPlaybackSpeedSubmenu, 200);
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window || event.data?.type !== 'ytsh-open-native-speed-menu') return;
    openYoutubeSpeedMenu();
  });

  window.addEventListener('ytsh-open-native-speed-menu', openYoutubeSpeedMenu);
})();
